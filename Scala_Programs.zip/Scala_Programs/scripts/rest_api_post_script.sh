#!/bin/bash

current_date=$(date +"%Y-%m-%d_H%-%M-%S")

export home_dir=
export post_url=$2
export get_url=$3
export log_file=$home_dir/post_job_$current_date.log
rest_response=""

echo "script to post job requests and capture the batch id" >> $log_file 2>&1

post_request(){
  request_json=$1
  curl -H "Content-Type: application/json" -d "@${request_json}" -X POST "${post_url}"
}

get_request(){
  rest_response=$(curl --request GET "${get_url}")
}

if [ $# -eq 0 ]
then
    echo "No arguments supplied, please provide required arguments" >>  $log_file 2>&1
    exit 1
fi

declare opt
declare OPTARG
declare OPTIND

while getopts a:b:c:d opt; do
  case $opt in
     a) request_type=$OPTARG
     ;;
     b) api_url=$OPTARG
     ;;
     c) request_json=$OPTARG
     ;;
     d) key=$OPTARG
     ;;
  esac
done

 if [ $request_type == "GET" ];
    then
        echo [`date +%Y-%m-%d:%H:%M:%S`]"Getting response." >> $log_file 2>&1
        get_request
        echo $rest_response | ed 's/"'${key}'"/\n'${key}'/g' | grep ''${key}'' | awk -F',' '{print $2}' >> $home_dir/batch_id.txt
 elif  [ $request_type == "post" ]; then
        echo [`date +%Y-%m-%d:%H:%M:%S`]"Posting the job." >> $log_file 2>&1
        post_request $request_json
 else
        echo "Invalid request type: ${request_type}, acceptable request types are: GET or POST"
        exit 1
fi
