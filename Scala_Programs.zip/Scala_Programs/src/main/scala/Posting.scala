import java.io.File

import com.fasterxml.jackson.databind.{JsonNode, ObjectMapper}
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.HttpClients
import play.api.libs.json.{JsObject, JsValue, Json}

import scala.io.Source
import scala.util.{Failure, Success, Try}


object Posting extends App {

  val yamlConfigPath = args(0)
  val postJobTemplateJsonPath = args(1)
  val postUrl = args(2)
  val authToken = args(3)
  val env = args(4)

  Try {
    val yamlMapper: ObjectMapper = new ObjectMapper(new YAMLFactory())
    val loadConfig = readYamlOrJson(yamlMapper, yamlConfigPath)
    val loadJobPostingJsonTemp = loadJSONJobTemplate(postJobTemplateJsonPath)
    val updatedJsonJobTemplate = updateJsonTemplate(loadJobPostingJsonTemp, loadConfig.get(env))
    postJob(Json.stringify(updatedJsonJobTemplate), postUrl, authToken)
  } match {
    case Failure(exception) => throw exception
    case Success(response) if response.getStatusLine.getStatusCode != 201 =>
      throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine.getStatusCode);
    case _ => println("job posted successfully")

  }

  private def readYamlOrJson(mapper: ObjectMapper, inputPath: String) = {
    val propsJsonString = mapper.writerWithDefaultPrettyPrinter.writeValueAsString(mapper.readValue(new File(inputPath), classOf[Any]))
    mapper.readTree(propsJsonString)
  }

  private def updateJsonTemplate(jsonTemp: Option[JsValue], confJsonObj: JsonNode): JsValue = {
    val jsonObj = jsonTemp.get.as[JsObject]
    val json = Json.obj("name" -> confJsonObj.get("dbname")) ++
      Json.obj("email_notifications" ->
        Json.obj("on_start" -> Json.arr("goutham471@gmail.com"),
          "on_success" -> Json.arr("goutham471@gmail.com", "goutham472@gmail.com")))

    println(Json.stringify(json))
    jsonObj.deepMerge(json)
  }

  private def postJob(jsonTemplate: String, url: String, autToken: String) = {
    val httpClient = HttpClients.createDefault()
    val postRequest = new HttpPost(url);
    val jobTemplateString = new StringEntity(jsonTemplate)

    jobTemplateString.setContentType("application/json")
    postRequest.setEntity(jobTemplateString)
    postRequest.setHeader("Authorization", "Bearer " + autToken)
    println("Posting job template: " + jsonTemplate)
    httpClient.execute(postRequest)
  }

  def loadJSONJobTemplate(filename: String): Option[JsValue] = {
    val bufferedSource = Source.fromFile(filename)
    Option(bufferedSource.mkString).map(Json.parse)
  }
}
