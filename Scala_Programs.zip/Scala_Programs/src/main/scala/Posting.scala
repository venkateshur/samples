import java.io.File

import com.fasterxml.jackson.databind.node.ObjectNode
import com.fasterxml.jackson.databind.{JsonNode, ObjectMapper}
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.HttpClients

import scala.util.{Failure, Success, Try}


object Posting extends App {

  val yamlConfigPath = args(0)
  val postJobTemplateJsonPath = args(1)
  val postUrl = args(2)

  Try {
    val mapper: ObjectMapper = new ObjectMapper(new YAMLFactory())
    val loadConfig = readYamlOrJson(mapper, yamlConfigPath)
    val loadJobPostingJsonTemp = readYamlOrJson(mapper, postJobTemplateJsonPath)
    val updatedJsonJobTemplate = updateJsonTemplate(loadJobPostingJsonTemp, loadConfig)
    postJob(updatedJsonJobTemplate.toPrettyString, postUrl)
  } match {
    case Failure(exception) => throw exception
    case Success(response) if response.getStatusLine.getStatusCode != 201 =>
      throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine.getStatusCode);
    case _ => println("job posted successfully")

  }

  private def readYamlOrJson(mapper: ObjectMapper, inputPath: String) = {
    val propsJsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readValue(new File(inputPath), classOf[Any]))
    mapper.readTree(propsJsonString)
  }

  private def updateJsonTemplate(jsonTemp: JsonNode, confJsonObj: JsonNode) = {
    val objectNode = jsonTemp.asInstanceOf[ObjectNode]
    objectNode.put("name", confJsonObj.get("DEV").get("dbname").textValue)
  }

  private def postJob(jsonTemplate: String, url: String) = {
    val httpClient = HttpClients.createDefault()
    val postRequest = new HttpPost(url);
    val jobTemplateString = new StringEntity(jsonTemplate)

    jobTemplateString.setContentType("application/json")
    postRequest.setEntity(jobTemplateString)
    println("Posting job template: " + jsonTemplate)
    httpClient.execute(postRequest)
  }
}
